# 比特币泡沫计算器

#### 项目介绍
根据币价、活跃地址总数、市场规模计算比特币泡沫大小


#### 使用说明

1. 本脚本需要python3解释执行，请下载并安装python3.6及以上版本
2. 安装完成后执行 py AnalasysBTCbubbles.py
3. 如果运行时报缺少xlsxwriter,请找到pip.exe（python3安装后就有）并执行 pip install xlsxwriter
4. 本脚本会自动下载所需数据并根据江卓尔先生的泡沫指数公式生成图表，并调用系统默认程序打开该图表。
